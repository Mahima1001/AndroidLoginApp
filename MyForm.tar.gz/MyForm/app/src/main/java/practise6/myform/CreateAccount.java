package practise6.myform;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import practise6.myform.com.DatabasePackage.DbHelper;
import practise6.myform.com.DatabasePackage.MyDatabase;

public class CreateAccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        Intent intent= getIntent();

        findViewById(R.id.btnSave)
                .setOnClickListener(new View
                        .OnClickListener() {
            @Override
            public void onClick(View v) {
                DbHelper helper = new DbHelper(CreateAccount.this, "MyFormDatabase", null, 1);
                MyDatabase database = new MyDatabase(helper);
                if(getUserName().equals(""))
                {
                    msg("Enter Username");
                }
                else if(getPassword().equals("")){
                    msg("Enter Password");
                }
                else if(getAddress().equals("")){
                    msg("Enter Address");
                }
                else if(getMobile().equals("")){
                    msg("Enter Contact No.");
                }
                else if(database.CheckForUniqueUsername(getUserName()).equals("You cannot use this username")){
                    msg(getUserName()+" has already been taken");
                }
                else if(database.CheckForUniquePhone(getMobile()).equals("You cannot use this phone no")){
                    msg(getMobile() + " has already been used");
                }
                else {

                    database.insert(getUserName(),
                            getPassword(),
                            getAddress(),
                            getEmail(),
                            getMobile());

                    finish();
                }
            }
        });

        findViewById(R.id.btnBackFromCreateAccount)
                .setOnClickListener(new View
                        .OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public String getUserName(){
        EditText username= (EditText) findViewById(R.id.edtusername);
        return username.getText().toString();
    }

    public String getPassword(){
        EditText password= (EditText) findViewById(R.id.edtpassword);
        return password.getText().toString();
    }

    public String getAddress(){
        EditText address= (EditText) findViewById(R.id.edtAddress);
        return address.getText().toString();
    }

    public String getEmail(){
        EditText email= (EditText) findViewById(R.id.edtEmail);
        return email.getText().toString();
    }

    public String getMobile(){
        EditText mobile= (EditText) findViewById(R.id.edtMobile);
        return mobile.getText().toString();
    }

    public void msg(String message){
        Toast.makeText(this,"Error->" + message,Toast.LENGTH_SHORT).show();
    }
}
