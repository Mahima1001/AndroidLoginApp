package practise6.myform;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import practise6.myform.com.DatabasePackage.DbHelper;
import practise6.myform.com.DatabasePackage.MyDatabase;

public class EditProfileActivity extends AppCompatActivity {





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        Intent intent= getIntent();
        Bundle bundle= intent.getExtras();
        final String username= bundle.getString(WelcomeActivity.KEY_ALLOW_EDIT);

        String password=null;
        String address=null;
        String email=null;
        String phone=null;

        EditText name= (EditText) findViewById(R.id.edtName);
        EditText pass= (EditText) findViewById(R.id.edtPass);
        EditText add= (EditText) findViewById(R.id.edtAdd);
        EditText emailid= (EditText) findViewById(R.id.edtEmailID);
        EditText ph= (EditText) findViewById(R.id.edtPhone);


        name.setText(username);

        DbHelper helper = new DbHelper(EditProfileActivity.this, "MyFormDatabase", null, 1);
        final MyDatabase database = new MyDatabase(helper);
        Cursor cursor=database.getInformation(username);
        while(cursor.moveToNext())
        {
            password=cursor.getString(cursor.getColumnIndex("Password"));
            address=cursor.getString(cursor.getColumnIndex("Address"));
            email=cursor.getString(cursor.getColumnIndex("Email"));
            phone=cursor.getString(cursor.getColumnIndex("Mobile"));
        }
        cursor.close();

        pass.setText(password);


        add.setText(address);

        emailid.setText(email);

        ph.setText(phone);

        findViewById(R.id.btnSaveTheEdit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText name= (EditText) findViewById(R.id.edtName);
                EditText ph= (EditText) findViewById(R.id.edtPhone);


                if(getUsername().equals("")){
                    msg("Enter Username");
                }
                else if(getPassword().equals("")){
                    msg("Enter Password");
                }
                else if(getAddress().equals("")){
                    msg("Enter Address");
                }
                else if(getMobile().equals(""))
                {
                    msg("Enter Mobile");
                }
                else if(!(getUsername().equals(name.getText().toString()))) {
                    if (database.CheckForUniqueUsername(getUsername()).equals("You cannot use this username")) {
                        msg(getUsername() + " has already been taken");
                    }
                }
                else if(!(getMobile().equals(ph.getText().toString()))) {
                    if (database.CheckForUniquePhone(getMobile()).equals("You cannot use this phone no")) {
                        msg(getMobile() + " has already been used");
                    }
                }
                else {
                    database.getEdit(getUsername(), getPassword(), getAddress(), getEmail(), getMobile(), username);
                    msg("Updated Successfully :)");
                }
            }
        });

        findViewById(R.id.btnBackFromEditActivity).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public String getUsername(){
        EditText username= (EditText) findViewById(R.id.edtName);
        return username.getText().toString();
    }

    public String getPassword(){
        EditText password= (EditText) findViewById(R.id.edtPass);
        return password.getText().toString();
    }

    public String getAddress(){
        EditText address= (EditText) findViewById(R.id.edtAdd);
        return  address.getText().toString();
    }

    public  String getEmail(){
        EditText email= (EditText) findViewById(R.id.edtEmailID);
        return  email.getText().toString();
    }

    public  String getMobile(){
        EditText mobile= (EditText) findViewById(R.id.edtPhone);
        return mobile.getText().toString();
    }

    public void msg(String message){
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
}
