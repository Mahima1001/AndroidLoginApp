package practise6.myform;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import practise6.myform.com.DatabasePackage.DbHelper;
import practise6.myform.com.DatabasePackage.MyDatabase;

public class LoginActivity extends AppCompatActivity {

    public static final String KEY_ALLOW = "Allow";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);
        Intent intent= getIntent();

        findViewById(R.id.btnLogin)
                .setOnClickListener(new View
                        .OnClickListener() {
            @Override
            public void onClick(View v) {

                DbHelper helper = new DbHelper(LoginActivity.this, "MyFormDatabase", null, 1);
                MyDatabase database = new MyDatabase(helper);

                if(getUsername()==null)
                {
                    msg("Username is must");
                }

                else if(getPassWord()==null)
                {
                    msg("Password is must");
                }
                else if(database.CheckLogin(getUsername(),getPassWord()).equals("Deny Login")){
                    msg("Username or Password is incorrect");
                }
                else{
                    Intent intent= new Intent(LoginActivity.this,WelcomeActivity.class);
                    Bundle bundle= new Bundle();
                    bundle.putString(KEY_ALLOW,getUsername());
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        });
    }

    public String getUsername(){
        EditText Username= (EditText) findViewById(R.id.edtUserName);
        return Username.getText().toString();
    }

    public String getPassWord(){
        EditText PassWord= (EditText) findViewById(R.id.edtPassword);
        return PassWord.getText().toString();
    }


    public void msg(String message){
        Toast.makeText(this,"Error->" + message,Toast.LENGTH_SHORT).show();
    }
}
