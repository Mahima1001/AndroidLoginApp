package practise6.myform;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import practise6.myform.com.DatabasePackage.DbHelper;
import practise6.myform.com.DatabasePackage.MyDatabase;

public class WelcomeActivity extends AppCompatActivity {

    public static final String KEY_ALLOW_EDIT = "AllowIt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        final Intent intent= getIntent();
        Bundle bundle= intent.getExtras();
        final String user_loggedin= bundle.getString(LoginActivity.KEY_ALLOW);
        TextView welcome_msg= (TextView) findViewById(R.id.txtWelcome);
        welcome_msg.setText("Welcome " + user_loggedin);

        findViewById(R.id.btnEditProfile)
                .setOnClickListener(new View
                        .OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentedit= new Intent(WelcomeActivity.this,EditProfileActivity.class);
                Bundle bundleedit= new Bundle();
                bundleedit.putString(KEY_ALLOW_EDIT,user_loggedin);
                intentedit.putExtras(bundleedit);
                startActivity(intentedit);
            }
        });

        findViewById(R.id.btnDeleteAccount).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DbHelper helper= new DbHelper(WelcomeActivity.this,"MyFormDatabase",null,1);
                MyDatabase database= new MyDatabase(helper);
                database.DeleteAccount(user_loggedin);
                finish();
            }
        });

        findViewById(R.id.btnLogOut).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
