package practise6.myform.com.DatabasePackage;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by HP on 28-06-2016.
 */
public class MyDatabase {
    DbHelper helper;
    public MyDatabase(DbHelper helper){
        this.helper= helper;
    }
    public void insert(String username,
                       String password,
                       String address,
                       String email,
                       String mobile){
        SQLiteDatabase sqdb= helper.getWritableDatabase();
        ContentValues values= new ContentValues();
        values.put("Username",username);
        values.put("Password",password);
        values.put("Address",address);
        values.put("Email",email);
        values.put("Mobile",mobile);

        sqdb.insert("information",null,values);

        sqdb.close();
    }

    public String CheckForUniqueUsername(String name){
        String table="information";
        String[] columns= new String[]{"Username"};
        String selection = "Username=?";
        String[] selectionArgs = new String[]{name};
        String groupBy= null;
        String having= null;
        String orderBy= null;

        String name_found=null;

        SQLiteDatabase sqdb= helper.getReadableDatabase();
        Cursor cursor= sqdb.query(table,columns,selection,selectionArgs,groupBy,having,orderBy);
        while(cursor.moveToNext()){
             name_found=cursor
                    .getString(cursor
                            .getColumnIndex("Username"));
            if(name_found.equals(name)){
                cursor.close();
                sqdb.close();
                return"You cannot use this username";
            }
        }
        cursor.close();
        sqdb.close();
        return "You can use this username";
    }

    public String CheckForUniquePhone(String phone){
        String table="information";
        String[] columns= new String[]{"Mobile"};
        String selection = "Mobile=?";
        String[] selectionArgs = new String[]{phone};
        String groupBy= null;
        String having= null;
        String orderBy= null;

        String mobile_found=null;

        SQLiteDatabase sqdb= helper.getReadableDatabase();
        Cursor cursor= sqdb.query(table,columns,selection,selectionArgs,groupBy,having,orderBy);
        while(cursor.moveToNext()){
            mobile_found=cursor
                    .getString(cursor
                            .getColumnIndex("Mobile"));
            if(mobile_found.equals(phone)){
                cursor.close();
                sqdb.close();
                return"You cannot use this phone no";
            }
        }
        cursor.close();
        sqdb.close();
        return "You can use this phone no";

    }

    public String CheckLogin(String username, String password){
        String table="information";
        String[] columns= new String[]{"Password"};
        String selection = "Username=?";
        String[] selectionArgs = new String[]{username};
        String groupBy= null;
        String having= null;
        String orderBy= null;

        String password_found=null;

        SQLiteDatabase sqdb= helper.getReadableDatabase();
        Cursor cursor= sqdb.query(table,columns,selection,selectionArgs,groupBy,having,orderBy);
        while(cursor.moveToNext()){
            password_found=cursor
                    .getString(cursor
                            .getColumnIndex("Password"));
            if(password_found.equals(password)){
                cursor.close();
                sqdb.close();
                return"Allow Login";
            }
        }
        cursor.close();
        sqdb.close();
        return "Deny Login";
    }

    public void DeleteAccount(String username){
        SQLiteDatabase sqdb= helper.getWritableDatabase();
        String table="information";
        String whereClause="Username=?";
        String[] whereArgs= new String[]{username};

        sqdb.delete(table,whereClause,whereArgs);
        sqdb.close();
    }

    public Cursor getInformation(String username){
        SQLiteDatabase sqdb= helper.getReadableDatabase();

        String table="information";
        String[] columns= new String[]{"Password","Address","Email","Mobile"};
        String selection = "Username=?";
        String[] selectionArgs = new String[]{username};
        String groupBy= null;
        String having= null;
        String orderBy= null;

        Cursor cursor= sqdb.query(table,columns,selection,selectionArgs,groupBy,having,orderBy);
        return  cursor;
    }

    public void getEdit(String name, String password,String address,String email,String phone,String oldname){
        SQLiteDatabase sqdb= helper.getWritableDatabase();

        String table="information";
        ContentValues values= new ContentValues();
        values.put("Username",name);
        values.put("Password",password);
        values.put("Address",address);
        values.put("Email",email);
        values.put("Mobile",phone);
        String whereClause = "Username=?";
        String[] whereArgs = new String[]{oldname};
        sqdb.update(table,values,whereClause,whereArgs);
        sqdb.close();
    }
}
